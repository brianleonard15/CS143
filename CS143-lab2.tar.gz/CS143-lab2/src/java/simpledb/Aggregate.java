package simpledb;

import java.util.*;

/**
 * The Aggregation operator that computes an aggregate (e.g., sum, avg, max,
 * min). Note that we only support aggregates over a single column, grouped by a
 * single column.
 */
public class Aggregate extends Operator {

    private static final long serialVersionUID = 1L;

    private DbIterator child;
    private int afield;
    private int gfield;
    private Aggregator.Op aop;

    private Aggregator agg;
    private DbIterator aggResults;
    /**
     * Constructor.
     * 
     * Implementation hint: depending on the type of afield, you will want to
     * construct an {@link IntAggregator} or {@link StringAggregator} to help
     * you with your implementation of readNext().
     * 
     * 
     * @param child
     *            The DbIterator that is feeding us tuples.
     * @param afield
     *            The column over which we are computing an aggregate.
     * @param gfield
     *            The column over which we are grouping the result, or -1 if
     *            there is no grouping
     * @param aop
     *            The aggregation operator to use
     */
    public Aggregate(DbIterator child, int afield, int gfield, Aggregator.Op aop) {
	    // some code goes here
        // Done
        this.child = child;
        this.afield = afield;
        this.gfield = gfield;
        this.aop = aop;
    }

    /**
     * @return If this aggregate is accompanied by a groupby, return the groupby
     *         field index in the <b>INPUT</b> tuples. If not, return
     *         {@link simpledb.Aggregator#NO_GROUPING}
     * */
    public int groupField() {
	    // some code goes here
        // Done
        return gfield == -1 ? Aggregator.NO_GROUPING : gfield;
    }

    /**
     * @return If this aggregate is accompanied by a group by, return the name
     *         of the groupby field in the <b>OUTPUT</b> tuples If not, return
     *         null;
     * */
    public String groupFieldName() {
	    // some code goes here
        // Done
        if (this.gfield != Aggregator.NO_GROUPING) {
            TupleDesc td = this.child.getTupleDesc();
            return td.getFieldName(this.gfield);
        }
        return null;
    }

    /**
     * @return the aggregate field
     * */
    public int aggregateField() {
	    // some code goes here
        // Done
        return this.afield;
    }

    /**
     * @return return the name of the aggregate field in the <b>OUTPUT</b>
     *         tuples
     * */
    public String aggregateFieldName() {
	    // some code goes here
        // Done
        TupleDesc td = this.child.getTupleDesc();
        return td.getFieldName(this.afield);
    }

    /**
     * @return return the aggregate operator
     * */
    public Aggregator.Op aggregateOp() {
	    // some code goes here
        // Done
        return this.aop;
    }

    public static String nameOfAggregatorOp(Aggregator.Op aop) {
	return aop.toString();
    }

    public void open() throws NoSuchElementException, DbException,
	    TransactionAbortedException {
	    // some code goes here
        // Done
        TupleDesc childTd = this.child.getTupleDesc();
        Type groupFieldType = this.gfield != -1 ? childTd.getFieldType(this.gfield) : null;
        Type aggFieldType = childTd.getFieldType(this.afield);
        switch (aggFieldType) {
            case INT_TYPE:
                this.agg = new IntegerAggregator(this.gfield, groupFieldType, this.afield, this.aop);
                break;
            case STRING_TYPE:
                this.agg = new StringAggregator(this.gfield, groupFieldType, this.afield, this.aop);
                break;
        }
        super.open();
        this.child.open();
        while (this.child.hasNext()) {
            this.agg.mergeTupleIntoGroup(this.child.next());
        }
        this.child.close();

        ArrayList<Tuple> tuples = new ArrayList<Tuple>();
        DbIterator aggIt = this.agg.iterator();
        aggIt.open();
        while (aggIt.hasNext()) {
            tuples.add(aggIt.next());
        }
        aggIt.close();
        this.aggResults = new TupleIterator(aggIt.getTupleDesc(), tuples);
        this.aggResults.open();
    }

    /**
     * Returns the next tuple. If there is a group by field, then the first
     * field is the field by which we are grouping, and the second field is the
     * result of computing the aggregate, If there is no group by field, then
     * the result tuple should contain one field representing the result of the
     * aggregate. Should return null if there are no more tuples.
     */
    protected Tuple fetchNext() throws TransactionAbortedException, DbException {
	    // some code goes here
        // Done
        while (this.aggResults.hasNext()) {
            return this.aggResults.next();
        }
        return null;
    }

    public void rewind() throws DbException, TransactionAbortedException {
	    // some code goes here
        // Done
        open();
    }

    /**
     * Returns the TupleDesc of this Aggregate. If there is no group by field,
     * this will have one field - the aggregate column. If there is a group by
     * field, the first field will be the group by field, and the second will be
     * the aggregate value column.
     * 
     * The name of an aggregate column should be informative. For example:
     * "aggName(aop) (child_td.getFieldName(afield))" where aop and afield are
     * given in the constructor, and child_td is the TupleDesc of the child
     * iterator.
     */
    public TupleDesc getTupleDesc() {
	    // some code goes here
        // Done
        TupleDesc childTd = this.child.getTupleDesc();
        TupleDesc td;
        if (this.gfield != Aggregator.NO_GROUPING) {
            Type[] typeAr = new Type[] {childTd.getFieldType(this.gfield), Type.INT_TYPE};
            String[] stringAr = new String[] {childTd.getFieldName(this.gfield), this.aop.toString() + "(" + childTd.getFieldName(this.afield) + ")"};
            td = new TupleDesc(typeAr, stringAr);
        } else {
            Type[] typeAr = new Type[] {Type.INT_TYPE};
            String[] stringAr = new String[] {this.aop.toString() + "(" + childTd.getFieldName(this.afield) + ")"};
            td = new TupleDesc(typeAr, stringAr);
        }
        return td;
    }

    public void close() {
	    // some code goes here
        // Done
        super.close();
        this.aggResults.close();
    }

    @Override
    public DbIterator[] getChildren() {
	    // some code goes here
        // Done
        return new DbIterator[] {this.child};
    }

    @Override
    public void setChildren(DbIterator[] children) {
	    // some code goes here
        // Done
        this.child = children[0];
    }
    
}
